/*
 * Cite Agent Launcher for Windows
 * Launches cite-agent in a new terminal window
 */

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX_PATH_LEN 4096

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    char appDir[MAX_PATH_LEN];
    char pythonExe[MAX_PATH_LEN];
    char commandLine[MAX_PATH_LEN];

    // Get the directory where the launcher is located
    GetModuleFileNameA(NULL, appDir, MAX_PATH_LEN);

    // Remove the launcher filename to get directory
    char* lastSlash = strrchr(appDir, '\\');
    if (lastSlash != NULL) {
        *lastSlash = '\0';
    }

    // Build path to Python executable
    snprintf(pythonExe, MAX_PATH_LEN, "%s\\python\\python.exe", appDir);

    // Build command line to launch cite-agent
    // Using cmd.exe to keep terminal open
    snprintf(commandLine, MAX_PATH_LEN,
        "cmd.exe /K \"\"%s\" -m cite_agent.cli\"",
        pythonExe
    );

    // Launch the command
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    // Start the process with a visible terminal window
    if (!CreateProcessA(
        NULL,           // No module name (use command line)
        commandLine,    // Command line
        NULL,           // Process handle not inheritable
        NULL,           // Thread handle not inheritable
        FALSE,          // Set handle inheritance to FALSE
        CREATE_NEW_CONSOLE, // Create new console window
        NULL,           // Use parent's environment block
        appDir,         // Use app directory as current directory
        &si,            // Pointer to STARTUPINFO structure
        &pi)            // Pointer to PROCESS_INFORMATION structure
    ) {
        MessageBoxA(NULL,
            "Failed to launch Cite Agent.\n\nPlease check your installation.",
            "Cite Agent Error",
            MB_ICONERROR | MB_OK);
        return 1;
    }

    // Close process and thread handles (we don't need them)
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    return 0;
}
